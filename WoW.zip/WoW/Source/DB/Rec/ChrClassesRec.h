#ifndef WOW_SOURCE_DB_REC_CHRCLASSESREC_H
#define WOW_SOURCE_DB_REC_CHRCLASSESREC_H

#include <cstddef>
#include <cstdint>

class SFileImpl;

class ChrClassesRec {
    public:
    static const int32_t s_numColumns = 60;
    static const int32_t s_rowSize = 240;
    static const bool s_generatedID = false;

    /* 0000 */ int32_t m_id;
    /* 0004 */ int32_t m_damageBonusStat;
    /* 0008 */ int32_t m_displayPower;
    /* 000C */ const char* m_petNameToken;
    /* 0010 */ const char* m_name;
    /* 0014 */ const char* m_nameFemale;
    /* 0018 */ const char* m_nameMale;
    /* 001C */ const char* m_filename;
    /* 0020 */ int32_t m_spellClassSet;
    /* 0024 */ int32_t m_flags;
    /* 0028 */ int32_t m_cinematicSequenceID;
    /* 002C */ int32_t m_requiredExpansion;

    ChrClassesRec();
    ~ChrClassesRec();
    static const char* GetFilename();
    bool Read(SFileImpl* file, const char* stringBuffer);
};

#endif
