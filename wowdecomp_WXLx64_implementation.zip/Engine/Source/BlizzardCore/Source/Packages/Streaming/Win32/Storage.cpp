#if defined(WOWDECOMP_ARCH_32)

#include <cstdint>
#include <cstring>
#include <deque>
#include <map>
#include <string>
#include <vector>
#include <windows.h>
#include "Engine/Source/BlizzardCore/Source/Packages/Streaming/Storage.h"
#include "Engine/Source/BlizzardCore/Source/Packages/Streaming/Streaming.h"
#include "Engine/Source/BlizzardCore/Source/System/File/File.h"
#include "Engine/Source/BlizzardCore/Source/System/File/Filestack.h"
#include "Engine/Source/BlizzardCore/Source/System/Log/Log.h"
#include "Engine/Source/BlizzardCore/Source/System/Memory/MemoryStorm.h"
#include "Engine/Source/BlizzardCore/Source/System/String/String.h"
#include "Engine/Source/BlizzardCore/Source/System/Thread/Thread.h"

// STATIC: 0x00AB909F
bool Blizzard::Storage::s_usePartFiles = true;

// STATIC: 0x00AB92BC
int32_t Blizzard::Storage::s_blockSize = 0x4000;

// STATIC: 0x00AB93CC
std::string Blizzard::Storage::s_storagePath;

// STATIC: 0x00B325C0
Blizzard::Lock::Mutex Blizzard::Storage::s_storageLock;

// STATIC: 0x00B325D8
void* Blizzard::Storage::s_storageEvent;

// STATIC: 0x00B38174
std::map<std::string, Blizzard::Streaming::StorageEntry>* Blizzard::Storage::s_storage;

// STATIC: 0x00B38178
Blizzard::File::StreamRecord* Blizzard::Storage::s_storageFile;

// STATIC: 0x00B3817C
bool Blizzard::Storage::s_storageReady;

// STATIC: 0x00B3817D
bool Blizzard::Storage::s_storageDirty;

// STATIC: 0x00B3817E
volatile bool Blizzard::Storage::s_storageStop;

// STATIC: 0x00B3817F
volatile bool Blizzard::Storage::s_storageStopped;

// STATIC: 0x00B3834C
std::deque<Blizzard::Streaming::WriteRequest> Blizzard::Storage::s_writeQueue;

// VERIFY: f7b739ba manual
// OFFSET: 0x00427F50
int32_t Blizzard::Storage::GetBlockLength(Blizzard::Streaming::StorageEntry* entry, int32_t block) {
    int32_t blockSize = entry->m_blockSize;

    if (entry->m_size <= (block + 1LL) * blockSize) {
        return static_cast<int32_t>(entry->m_size - static_cast<int64_t>(block) * blockSize);
    }

    return entry->m_blockSize;
}

// VERIFY: 0dc55920 manual
// OFFSET: 0x00427FB0
int32_t Blizzard::Storage::CountRanges(Blizzard::Streaming::StorageEntry* entry, int64_t offset, int64_t size) {
    return static_cast<int32_t>((size + offset) / entry->m_blockSize - offset / entry->m_blockSize + 4);
}

// VERIFY: 7a1edb4d auto
// OFFSET: 0x0042CEF0
bool Blizzard::Storage::ReadAt(Blizzard::File::Filesystem* fs, Blizzard::File::StreamRecord* file, void* buffer, int64_t offset, int32_t size) {
    return Blizzard::File::Read(fs, file, buffer, offset, &size);
}

// VERIFY: 93c137d2 auto
// OFFSET: 0x0042CF20
bool Blizzard::Storage::WriteAt(Blizzard::File::StreamRecord* file, const void* buffer, int64_t offset, int32_t size) {
    return Blizzard::File::Write(file, buffer, offset, &size);
}

// VERIFY: 26ae7efd manual
// OFFSET: 0x0042D820
bool Blizzard::Storage::IsComplete(Blizzard::Streaming::StorageEntry* entry) {
    for (int32_t i = 0; i < static_cast<int32_t>(entry->m_blocks.size()); i++) {
        if (entry->m_blocks[i].m_state != 3) {
            return false;
        }
    }

    return true;
}

// VERIFY: 5e4c6096 manual
// OFFSET: 0x0042D880
int32_t Blizzard::Storage::BuildRanges(Blizzard::Streaming::StorageEntry* entry, int64_t offset, int32_t size, Blizzard::Streaming::LoadRange* ranges) {
    int64_t position = offset;
    uint32_t block = static_cast<uint32_t>(offset / entry->m_blockSize);
    int32_t count = 0;

    for (int32_t phase = 1; size && phase <= 3; phase++) {
        if (phase == 2) {
            int32_t full = entry->m_blockSize * (size / entry->m_blockSize);

            while (full >= entry->m_blockSize) {
                int32_t state = entry->m_blocks[block].m_state;
                Blizzard::Streaming::LoadRange& range = ranges[count];

                switch (state) {
                    case 0:
                    case 1:
                        count++;
                        range.m_offset = position;
                        range.m_blockOffset = position;
                        range.m_size = entry->m_blockSize;
                        range.m_blockSize = entry->m_blockSize;
                        range.m_state = 3 - (state != 1);
                        break;

                    case 2:
                    case 3:
                    case 4:
                        count++;
                        range.m_size = entry->m_blockSize;
                        range.m_offset = static_cast<int64_t>(block) * entry->m_blockSize;
                        range.m_blockOffset = 0;
                        range.m_blockSize = 0;
                        range.m_state = state == 4;
                        break;
                }

                block++;
                size -= entry->m_blockSize;
                position += entry->m_blockSize;
                full -= entry->m_blockSize;
            }

            continue;
        }

        int64_t blockStart = static_cast<int64_t>(block) * entry->m_blockSize;

        if (phase == 1 && position == blockStart) {
            continue;
        }

        int32_t inner = static_cast<int32_t>(position - blockStart);
        int32_t length = GetBlockLength(entry, block);
        int32_t state = entry->m_blocks[block].m_state;
        int32_t available = length - inner;
        int32_t take = size >= available ? available : size;

        switch (state) {
            case 0:
            case 1: {
                Blizzard::Streaming::LoadRange& range = ranges[count++];
                size -= take;
                range.m_offset = position;
                range.m_blockOffset = blockStart;
                range.m_size = take;
                range.m_blockSize = length;
                range.m_state = 3 - (state != 1);
                break;
            }

            case 2:
            case 3:
            case 4: {
                Blizzard::Streaming::LoadRange& range = ranges[count++];
                range.m_offset = inner + entry->m_blockSize * static_cast<int64_t>(block);
                size -= take;
                range.m_size = take;
                range.m_blockOffset = 0;
                range.m_blockSize = 0;
                range.m_state = state == 4;
                break;
            }
        }

        block++;
        position += entry->m_blockSize - inner;
    }

    return count;
}

// VERIFY: b2dea1aa manual
// OFFSET: 0x0042DB80
int32_t Blizzard::Storage::BuildRangesFromStore(Blizzard::Streaming::StorageEntry* entry, int64_t offset, int32_t size, Blizzard::Streaming::LoadRange* ranges) {
    int64_t start = entry->m_storeSize >= offset ? offset : entry->m_storeSize;
    int32_t count = 0;

    if (start / entry->m_blockSize < offset / entry->m_blockSize) {
        count = BuildRanges(entry, entry->m_storeSize, static_cast<int32_t>(offset / entry->m_blockSize * entry->m_blockSize - entry->m_storeSize), ranges);

        for (int32_t i = 0; i < count; i++) {
            ranges[i].m_state = 4;
        }
    }

    return count + BuildRanges(entry, offset, size, ranges + count);
}

// VERIFY: 66582138 manual
// OFFSET: 0x0042DC70
int32_t Blizzard::Storage::BuildRangesWithHeader(Blizzard::Streaming::StorageEntry* entry, int64_t offset, int32_t size, Blizzard::Streaming::LoadRange* ranges) {
    if (entry->m_blocks[0].m_state == 3) {
        return BuildRanges(entry, offset, size, ranges);
    }

    if (entry->m_blocks[0].m_state == 2) {
        return BuildRanges(entry, offset, size, ranges);
    }

    int32_t total = static_cast<int32_t>(entry->m_size / entry->m_blockSize + 1);
    int32_t first = static_cast<int32_t>(offset / entry->m_blockSize);
    int32_t head = 0;

    if (first > 0) {
        head = first;

        for (int32_t i = 0; i < first; i++) {
            Blizzard::Streaming::LoadRange& range = ranges[i];
            int32_t length = GetBlockLength(entry, i);
            range.m_offset = 0;
            range.m_size = 0;
            range.m_blockOffset = static_cast<int64_t>(i) * entry->m_blockSize;
            range.m_blockSize = length;
            range.m_state = 4;
        }
    }

    int32_t count = BuildRanges(entry, offset, size, ranges + head) + head;
    int32_t next = static_cast<int32_t>((offset + size - 1) / entry->m_blockSize + 1);

    if (next < total) {
        Blizzard::Streaming::LoadRange* range = &ranges[count];
        count += total - next;

        for (; next < total; next++, range++) {
            int64_t end = (next + 1LL) * entry->m_blockSize;
            int32_t length = entry->m_size <= end ? static_cast<int32_t>(entry->m_size - static_cast<int64_t>(next) * entry->m_blockSize) : entry->m_blockSize;

            range->m_offset = 0;
            range->m_size = 0;
            range->m_blockOffset = static_cast<int64_t>(next) * entry->m_blockSize;
            range->m_blockSize = length;
            range->m_state = 4;
        }
    }

    return count;
}

// VERIFY: bf328490 manual
// OFFSET: 0x0042DE70
bool Blizzard::Storage::RequestRange(Blizzard::Streaming::StorageEntry* entry, int64_t offset, int32_t size, int32_t state) {
    EnterCriticalSection(&s_storageLock);

    if (entry->m_closed) {
        LeaveCriticalSection(&s_storageLock);
        return false;
    }

    int64_t blockSize = entry->m_blockSize;
    int32_t last = static_cast<int32_t>((offset + size - 1) / blockSize);

    for (uint32_t block = static_cast<uint32_t>(offset / blockSize); static_cast<int32_t>(block) <= last; block++) {
        Blizzard::Streaming::StorageBlock& storageBlock = entry->m_blocks[block];

        if (state != 1 || (storageBlock.m_state != 2 && storageBlock.m_state != 3)) {
            storageBlock.m_state = state;
        }
    }

    LeaveCriticalSection(&s_storageLock);
    return true;
}

// VERIFY: 3a968ae6 manual
// OFFSET: 0x0042DF70
void Blizzard::Storage::SetRangeAs(Blizzard::Streaming::StorageEntry* entry, int64_t offset, int32_t size, int32_t state) {
    int32_t first = static_cast<int32_t>(offset / entry->m_blockSize);
    int32_t last = size <= 0 ? first : static_cast<int32_t>((offset + size - 1) / entry->m_blockSize);

    EnterCriticalSection(&s_storageLock);

    for (uint32_t block = first; static_cast<int32_t>(block) <= last; block++) {
        entry->m_blocks[block].m_state = state;
    }

    LeaveCriticalSection(&s_storageLock);
}

// VERIFY: 4073f769 manual
// OFFSET: 0x00432530
Blizzard::Storage::StorageEntryRef::StorageEntryRef(Blizzard::Streaming::StorageEntry* entry) {
    EnterCriticalSection(&s_storageLock);

    if (!entry || entry->m_released) {
        LeaveCriticalSection(&s_storageLock);
        this->m_entry = nullptr;
        return;
    }

    entry->m_refCount++;
    LeaveCriticalSection(&s_storageLock);
    this->m_entry = entry;
}

// VERIFY: 702babd3 manual
// OFFSET: 0x004327D0
bool Blizzard::Storage::WriteIndexEntry(Blizzard::Streaming::StorageEntry* entry, int32_t block, bool header) {
    if (!s_storageReady) {
        return false;
    }

    if (entry->m_flags & 4) {
        return true;
    }

    if (!header) {
        int32_t amount = 8;
        Blizzard::File::Write(s_storageFile, &entry->m_storeSize, entry->m_headerOffset + 305, &amount);

        if (block >= 0 && block < static_cast<int32_t>(entry->m_blocks.size())) {
            Blizzard::Streaming::StorageBlockRecord record;
            record.m_state = entry->m_blocks[block].m_state;
            record.m_offset = entry->m_blocks[block].m_offset;
            record.m_storeOffset = entry->m_blocks[block].m_storeOffset;
            record.m_size = entry->m_blocks[block].m_size;

            WriteAt(s_storageFile, &record, entry->m_headerOffset + 24LL * block + 321, 24);
        }

        return true;
    }

    int32_t version = 2;
    Blizzard::File::SetPos(s_storageFile, 0, 0);
    int32_t count = 4;
    Blizzard::File::Write(s_storageFile, &version, &count);

    int32_t entries = static_cast<int32_t>(s_storage->size());
    count = 4;
    Blizzard::File::Write(s_storageFile, &entries, &count);

    Blizzard::Streaming::StorageHeader storageHeader;
    storageHeader.m_flags = entry->m_flags;
    storageHeader.m_storeSize = entry->m_storeSize;
    Blizzard::String::Copy(storageHeader.m_path, entry->m_path.c_str(), sizeof(storageHeader.m_path));
    Blizzard::String::Copy(storageHeader.m_version, entry->m_version.c_str(), sizeof(storageHeader.m_version));
    storageHeader.m_closed = entry->m_closed;
    storageHeader.m_size = entry->m_size;
    storageHeader.m_blockSize = entry->m_blockSize;
    storageHeader.m_blockCount = static_cast<int32_t>(entry->m_blocks.size());

    int32_t amount = sizeof(storageHeader);
    Blizzard::File::Write(s_storageFile, &storageHeader, entry->m_headerOffset, &amount);

    amount = 24 * storageHeader.m_blockCount;
    Blizzard::File::Write(s_storageFile, &entry->m_blocks[0], entry->m_headerOffset + 321, &amount);

    return true;
}

// VERIFY: 21819d87 manual
// OFFSET: 0x00432A40
Blizzard::Streaming::LoadRange* Blizzard::Storage::GetRange(Blizzard::Streaming::StorageEntry* entry, int64_t offset, int32_t size, int32_t* count, bool lock) {
    int64_t zero = 0;
    int64_t start = offset >= 0 ? offset : zero;
    start = entry->m_size >= start ? start : entry->m_size;

    int64_t end = start + size;
    zero = 0;
    end = end >= 0 ? end : zero;
    end = entry->m_size >= end ? end : entry->m_size;

    int32_t length = static_cast<int32_t>(end - start);

    if (end == start) {
        *count = 0;
        return nullptr;
    }

    if (lock) {
        EnterCriticalSection(&s_storageLock);
    }

    Blizzard::Streaming::LoadRange* ranges;

    if (entry->m_flags & 2) {
        ranges = static_cast<Blizzard::Streaming::LoadRange*>(Blizzard::Memory::Allocate(sizeof(Blizzard::Streaming::LoadRange) * CountRanges(entry, 0, entry->m_size)));
        *count = BuildRangesWithHeader(entry, start, length, ranges);
    } else if (entry->m_flags & 1) {
        zero = 0;
        int64_t from = entry->m_storeSize >= 0 ? entry->m_storeSize : zero;
        from = start >= from ? from : start;
        ranges = static_cast<Blizzard::Streaming::LoadRange*>(Blizzard::Memory::Allocate(sizeof(Blizzard::Streaming::LoadRange) * CountRanges(entry, from, start + length - from)));
        *count = BuildRangesFromStore(entry, start, length, ranges);
    } else {
        ranges = static_cast<Blizzard::Streaming::LoadRange*>(Blizzard::Memory::Allocate(sizeof(Blizzard::Streaming::LoadRange) * CountRanges(entry, start, length)));
        *count = BuildRanges(entry, start, length, ranges);
    }

    if (lock) {
        LeaveCriticalSection(&s_storageLock);
    }

    return ranges;
}

// VERIFY: 9eae04c9 manual
// OFFSET: 0x00435A60
int64_t Blizzard::Storage::GetNextHeaderOffset() {
    int64_t offset = 8;

    for (std::map<std::string, Blizzard::Streaming::StorageEntry>::iterator it = s_storage->begin(); it != s_storage->end(); ++it) {
        if (it->second.m_flags & 4) {
            continue;
        }

        if (offset <= it->second.m_headerOffset) {
            offset = it->second.m_headerOffset + static_cast<int64_t>(24 * static_cast<int32_t>(it->second.m_blocks.size())) + 321;
        }
    }

    return offset;
}

// VERIFY: 66d08f5d manual
// OFFSET: 0x00439C40
bool Blizzard::Storage::ReadLocal(Blizzard::File::Filesystem* fs, Blizzard::File::StreamRecord* file, Blizzard::Streaming::StorageEntry* entry, uint8_t* buffer, int64_t offset, int32_t size) {
    EnterCriticalSection(&s_storageLock);

    bool result = false;
    int32_t block = static_cast<int32_t>(offset / entry->m_blockSize);
    Blizzard::Streaming::StorageBlock& storageBlock = entry->m_blocks[block];
    int64_t position = offset + storageBlock.m_storeOffset - static_cast<int64_t>(entry->m_blockSize) * block;

    if (entry->m_flags & 4) {
        LeaveCriticalSection(&s_storageLock);
        return false;
    }

    if (storageBlock.m_state != 2) {
        if (storageBlock.m_state == 3) {
            int32_t amount = size;
            result = Blizzard::File::Read(fs, file, buffer, position, &amount);
            LeaveCriticalSection(&s_storageLock);
            return result;
        }

        if (storageBlock.m_state != 4) {
            LeaveCriticalSection(&s_storageLock);
            return false;
        }

        LeaveCriticalSection(&s_storageLock);

        while (storageBlock.m_state == 4) {
            Sleep(1);
        }

        EnterCriticalSection(&s_storageLock);

        if (storageBlock.m_state == 3) {
            result = ReadAt(fs, file, buffer, offset + storageBlock.m_storeOffset - static_cast<int64_t>(entry->m_blockSize) * block, size);
            LeaveCriticalSection(&s_storageLock);
            return result;
        }

        result = false;
    }

    int32_t count = static_cast<int32_t>(s_writeQueue.size());

    for (int32_t i = 0; i < count; i++) {
        Blizzard::Streaming::WriteRequest& request = s_writeQueue[i];

        if (entry == request.m_entry && entry->m_blockSize * block == static_cast<int32_t>(request.m_offset)) {
            Blizzard::String::MemCopy(buffer, request.m_data + offset - static_cast<int64_t>(block) * entry->m_blockSize, size);
            result = true;
            break;
        }
    }

    LeaveCriticalSection(&s_storageLock);
    return result;
}

// VERIFY: 6392bebc manual
// OFFSET: 0x004443E0
bool Blizzard::Storage::QueueWrite(Blizzard::File::Filesystem* fs, Blizzard::File::StreamRecord* file, uint8_t* data, int64_t offset, int32_t size, bool owned) {
    EnterCriticalSection(&s_storageLock);

    Blizzard::Streaming::StorageEntry* entry = file->m_streaming->m_entry;
    Blizzard::Streaming::AddStreamed(size);

    uint32_t block = static_cast<uint32_t>(offset / entry->m_blockSize);
    Blizzard::Streaming::StorageBlock& storageBlock = entry->m_blocks[block];

    if (!(entry->m_flags & 4)) {
        if (!storageBlock.m_state || storageBlock.m_state == 1 || storageBlock.m_state == 4) {
            Blizzard::Streaming::WriteRequest request;
            request.m_fs = fs;
            request.m_pending = 1;
            request.m_file = file;
            request.m_entry = entry;
            request.m_offset = offset;
            request.m_size = size;

            if (owned) {
                request.m_data = data;
            } else {
                request.m_data = static_cast<uint8_t*>(Blizzard::Memory::Allocate(size));
                memmove(request.m_data, data, size);
            }

            storageBlock.m_state = 2;
            s_storageDirty = true;
            s_writeQueue.push_back(request);
            SetEvent(s_storageEvent);
        } else if (owned) {
            Blizzard::Memory::Free(data);
        }
    }

    LeaveCriticalSection(&s_storageLock);
    return true;
}

// VERIFY: 39a74cbc manual
// OFFSET: 0x00447BF0
bool Blizzard::Storage::WriteIndex() {
    if (!s_storageReady) {
        return false;
    }

    if (!s_storageDirty) {
        return true;
    }

    int32_t version = 2;
    Blizzard::File::SetPos(s_storageFile, 0, 0);
    int32_t count = 4;
    Blizzard::File::Write(s_storageFile, &version, &count);

    int32_t entries = static_cast<int32_t>(s_storage->size());
    count = 4;
    Blizzard::File::Write(s_storageFile, &entries, &count);

    std::vector<Blizzard::Streaming::StorageBlockRecord> records;

    for (std::map<std::string, Blizzard::Streaming::StorageEntry>::iterator it = s_storage->begin(); it != s_storage->end(); ++it) {
        Blizzard::Streaming::StorageEntry& entry = it->second;

        if (entry.m_flags & 4) {
            continue;
        }

        Blizzard::Streaming::StorageHeader header;
        header.m_flags = entry.m_flags;
        header.m_storeSize = entry.m_storeSize;

        const char* path = entry.m_path.c_str();

        if (path) {
            char* dst = header.m_path;

            do {
                char c = *path++;

                if (!c) {
                    break;
                }

                *dst++ = c;
            } while (dst < &header.m_path[sizeof(header.m_path) - 1]);

            *dst = '\0';
        } else {
            header.m_path[0] = '\0';
        }

        const char* version = entry.m_version.c_str();

        if (version) {
            char* dst = header.m_version;

            do {
                char c = *version++;

                if (!c) {
                    break;
                }

                *dst++ = c;
            } while (dst < &header.m_version[sizeof(header.m_version) - 1]);

            *dst = '\0';
        } else {
            header.m_version[0] = '\0';
        }

        header.m_size = entry.m_size;
        header.m_closed = entry.m_closed;
        header.m_blockSize = entry.m_blockSize;
        header.m_blockCount = static_cast<int32_t>(entry.m_blocks.size());

        int32_t amount = sizeof(header);
        Blizzard::File::Write(s_storageFile, &header, &amount);

        records.resize(header.m_blockCount);

        for (int32_t i = 0; i < header.m_blockCount; i++) {
            records[i].m_state = entry.m_blocks[i].m_state;
            records[i].m_offset = entry.m_blocks[i].m_offset;
            records[i].m_storeOffset = entry.m_blocks[i].m_storeOffset;
            records[i].m_size = entry.m_blocks[i].m_size;
        }

        amount = 24 * header.m_blockCount;
        Blizzard::File::Write(s_storageFile, &records[0], -1LL, &amount);
    }

    Blizzard::File::SetEOF(s_storageFile, 0, 1);
    s_storageDirty = false;

    return true;
}

// VERIFY: d17bd1fe manual
// OFFSET: 0x0044CB90
bool Blizzard::Storage::Remove(const std::string& path) {
    std::map<std::string, Blizzard::Streaming::StorageEntry>::iterator it = s_storage->find(Blizzard::Streaming::ResolveFilePath(path));

    if (it == s_storage->end()) {
        return false;
    }

    s_storage->erase(it);
    return true;
}

// VERIFY: bf3a0fcd manual
// OFFSET: 0x0044E580
bool Blizzard::Storage::ReadStorageFile(const uint8_t* data, int32_t size) {
    Blizzard::Streaming::StorageEntry entry;

    if (size < 4 || size - 4 < 4) {
        return false;
    }

    const uint8_t* cursor = data + 8;
    int32_t left = size - 8;
    int32_t count = *reinterpret_cast<const int32_t*>(data + 4);

    for (int32_t i = 0; i < count && left > 0; i++) {
        if (left < 321) {
            s_storage->clear();
            return false;
        }

        const Blizzard::Streaming::StorageHeader* header = reinterpret_cast<const Blizzard::Streaming::StorageHeader*>(cursor);
        const uint8_t* blocks = cursor + 321;
        left -= 321;

        entry.m_path.assign(header->m_path, strlen(header->m_path));
        entry.m_version.assign(header->m_version, strlen(header->m_version));
        entry.m_storeSize = header->m_storeSize;
        entry.m_size = header->m_size;
        entry.m_flags = header->m_flags;
        entry.m_blockSize = header->m_blockSize;
        entry.m_closed = header->m_closed;
        entry.m_headerWritten = false;
        entry.m_headerOffset = size - left - 321;

        if (!entry.m_blockSize || (entry.m_size + entry.m_blockSize - 1) / entry.m_blockSize != header->m_blockCount) {
            s_storage->clear();
            return false;
        }

        (*s_storage)[Blizzard::Streaming::ResolveFilePath(entry.m_path)] = entry;
        Blizzard::Streaming::StorageEntry& stored = (*s_storage)[Blizzard::Streaming::ResolveFilePath(entry.m_path)];

        int32_t bytes = 24 * header->m_blockCount;

        if (left < bytes) {
            s_storage->clear();
            return false;
        }

        std::vector<Blizzard::Streaming::StorageBlockRecord> records;
        records.resize(header->m_blockCount);
        Blizzard::String::MemCopy(&records[0], blocks, bytes);

        stored.m_blocks.resize(header->m_blockCount);

        for (int32_t j = 0; j < header->m_blockCount; j++) {
            Blizzard::Streaming::StorageBlock& storageBlock = stored.m_blocks[j];
            storageBlock.m_offset = records[j].m_offset;
            storageBlock.m_size = records[j].m_size;
            storageBlock.m_storeOffset = records[j].m_storeOffset;
            storageBlock.m_partOffset = records[j].m_storeOffset;
            storageBlock.m_state = records[j].m_state;
        }

        cursor = blocks + bytes;
        left -= bytes;
    }

    return true;
}

// VERIFY: cb6770b1 manual
// OFFSET: 0x0044EA50
Blizzard::Streaming::StorageEntry* Blizzard::Storage::PartialFile::CreateShared(const std::string& key, const char* path, int64_t size, const char* version, int32_t flags) {
    Blizzard::Streaming::StorageEntry entry;
    entry.m_path.assign(path, strlen(path));
    entry.m_version.assign(version, strlen(version));
    entry.m_flags = flags;
    entry.m_closed = false;
    entry.m_released = false;
    entry.m_refCount = 0;
    entry.m_size = size;
    entry.m_storeSize = 0;
    entry.m_blockSize = s_blockSize;
    entry.m_headerWritten = true;
    entry.m_file = nullptr;
    entry.m_openCount = 0;
    InitializeCriticalSection(&entry.m_lock);

    int32_t count = static_cast<int32_t>((size + entry.m_blockSize - 1) / entry.m_blockSize);

    if (s_usePartFiles) {
        entry.m_blocks.resize(count, Blizzard::Streaming::StorageBlock());
        memset(&entry.m_blocks[0], 0, sizeof(Blizzard::Streaming::StorageBlock) * count);
        (*s_storage)[key] = entry;
    } else {
        entry.m_blocks.resize(count, Blizzard::Streaming::StorageBlock());

        int32_t left = static_cast<int32_t>(size);

        for (uint32_t i = 0; i < entry.m_blocks.size(); i++) {
            Blizzard::Streaming::StorageBlock& block = entry.m_blocks[i];
            block.m_state = 0;
            block.m_offset = static_cast<int64_t>(entry.m_blockSize) * i;
            block.m_storeOffset = 0;
            block.m_partOffset = 0;
            block.m_size = i < entry.m_blocks.size() - 1 ? entry.m_blockSize : left;
            left -= entry.m_blockSize;
        }

        entry.m_headerOffset = GetNextHeaderOffset();
        (*s_storage)[key] = entry;
        WriteIndexEntry(&entry, -1, true);
    }

    return &(*s_storage)[key];
}

// VERIFY: ed165c96 manual
// OFFSET: 0x0044ED80
Blizzard::Streaming::StorageEntry* Blizzard::Storage::Acquire(Blizzard::File::Filesystem* fs, const std::string& key, const char* path, int64_t size, const char* version, int32_t flags) {
    if (!s_storage) {
        return nullptr;
    }

    if (!path) {
        std::map<std::string, Blizzard::Streaming::StorageEntry>::iterator it = s_storage->find(key);

        if (it == s_storage->end()) {
            return nullptr;
        }

        return &it->second;
    }

    EnterCriticalSection(&s_storageLock);

    std::map<std::string, Blizzard::Streaming::StorageEntry>::iterator it = s_storage->find(key);

    char partName[260];
    BuildVariantFileName(partName, sizeof(partName), path, "part");

    if (it != s_storage->end()) {
        Blizzard::File::FileInfo info;

        if (it->second.m_headerWritten || (Blizzard::File::GetFileInfo(fs, partName, &info) && info.m_size == it->second.m_storeSize && size == it->second.m_size && Blizzard::String::Equal(version, it->second.m_version.c_str()))) {
            Blizzard::Streaming::StorageEntry* entry = &it->second;
            LeaveCriticalSection(&s_storageLock);
            return entry;
        }

        Remove(it->second.m_path);
    }

    if (!s_usePartFiles) {
        Blizzard::File::Delete(partName);
    }

    Blizzard::Streaming::StorageEntry* entry = PartialFile::CreateShared(key, path, size, version, flags);
    LeaveCriticalSection(&s_storageLock);
    return entry;
}

// VERIFY: 02a9aee2 manual
// OFFSET: 0x004508B0
void Blizzard::Storage::Shutdown() {
    if (s_storageReady && s_storage) {
        s_storageStop = true;
        SetEvent(s_storageEvent);

        while (!s_storageStopped) {
            Sleep(10);
        }

        CloseHandle(s_storageEvent);
        DeleteCriticalSection(&s_storageLock);
        s_storageLock.DebugInfo = nullptr;

        if (s_storageFile) {
            Blizzard::File::Close(s_storageFile);
        }
    }

    delete s_storage;
    s_storage = nullptr;
}

// VERIFY: 43918f20 manual
// OFFSET: 0x00456DE0
bool Blizzard::Storage::PartialFile::RebuildHeader(Blizzard::File::Filesystem* fs, Blizzard::File::StreamRecord* file) {
    Blizzard::Log::Printf(3, "Logs/Profiling_Storage_Initialization.log", "Reinitialized Part file '%s' started.\n", file->m_pathname);

    Blizzard::File::StreamingInfo* streaming = file->m_streaming;

    if (!streaming || !streaming->m_entry) {
        return false;
    }

    Blizzard::Streaming::StorageEntry* entry = streaming->m_entry;

    Blizzard::Streaming::PartFileHeader header;
    header.m_magic = 2;
    Blizzard::String::Copy(header.m_version, entry->m_version.c_str(), sizeof(header.m_version));
    header.m_flags = entry->m_flags;
    header.m_size = entry->m_size;
    header.m_blockSize = entry->m_blockSize;

    int32_t count = static_cast<int32_t>((header.m_size + header.m_blockSize - 1) / header.m_blockSize);
    entry->m_blocks.resize(count);
    memset(&entry->m_blocks[0], 0, sizeof(Blizzard::Streaming::StorageBlock) * count);

    int32_t amount = sizeof(header);

    if (!Blizzard::File::Write(file, &header, 0, &amount)) {
        Blizzard::File::AddToLastErrorStack(0, "FileStack_Streaming::StreamingOpen - Failed to write .part header section", 20);
        return false;
    }

    amount = 20 * count;

    if (!Blizzard::File::Write(file, &entry->m_blocks[0], 52, &amount)) {
        Blizzard::File::AddToLastErrorStack(0, "FileStack_Streaming::StreamingOpen - Failed to write .part storage section", 20);
        return false;
    }

    int64_t end = 20LL * count + 52;
    entry->m_storeSize = end;
    entry->m_headerWritten = true;
    entry->m_closed = false;
    entry->m_parsed = true;
    Blizzard::File::SetEOF(file, end, 0);

    Blizzard::Log::Printf(3, "Logs/Profiling_Storage_Initialization.log", "Reinitialized Part file '%s' succeeded.\n", file->m_pathname);
    return true;
}

// VERIFY: d92a96a2 manual
// OFFSET: 0x00456F80
bool Blizzard::Storage::PartialFile::ParseFile(Blizzard::File::Filesystem* fs, Blizzard::File::StreamRecord* file) {
    Blizzard::File::StreamingInfo* streaming = file->m_streaming;

    if (!streaming || !streaming->m_entry) {
        return false;
    }

    Blizzard::Streaming::StorageEntry* entry = streaming->m_entry;

    if (entry->m_parsed) {
        return true;
    }

    if (streaming->m_info.m_size < 52) {
        return RebuildHeader(fs, file);
    }

    Blizzard::Streaming::PartFileHeader header;
    int32_t amount = sizeof(header);
    Blizzard::File::Read(fs, file, &header, 0, &amount);

    if (!header.m_blockSize || entry->m_version.compare(header.m_version) || header.m_size != file->m_info.m_size || header.m_magic != 2) {
        return RebuildHeader(fs, file);
    }

    entry->m_flags = header.m_flags;
    entry->m_storeSize = file->m_streaming->m_info.m_size;

    int32_t count = static_cast<int32_t>((entry->m_blockSize + entry->m_size - 1) / entry->m_blockSize);
    int32_t bytes = 20 * count;
    uint8_t* raw = new uint8_t[bytes];

    std::vector<Blizzard::Streaming::PartBlockRecord> records;
    records.resize(count);

    amount = bytes;
    Blizzard::File::Read(fs, file, raw, 52, &amount);

    if (amount < bytes) {
        delete[] raw;
        return RebuildHeader(fs, file);
    }

    Blizzard::String::MemCopy(&records[0], raw, amount);
    delete[] raw;

    entry->m_blocks.resize(count);

    int32_t local = 0;

    for (int32_t i = 0; i < count; i++) {
        Blizzard::Streaming::StorageBlock& block = entry->m_blocks[i];
        block.m_offset = 0;
        block.m_size = entry->m_blockSize;
        block.m_storeOffset = records[i].m_storeOffset;
        block.m_partOffset = records[i].m_partOffset;
        block.m_state = records[i].m_state != 0 ? 3 : 0;

        if (block.m_state == 3) {
            if (block.m_storeOffset > entry->m_storeSize) {
                return RebuildHeader(fs, file);
            }

            local++;
        }
    }

    int64_t end = bytes + static_cast<int64_t>(local) * entry->m_blockSize + 52;

    if (entry->m_storeSize > end) {
        Blizzard::File::SetEOF(file, end, 0);
        entry->m_storeSize = end;
    } else if (entry->m_storeSize < end) {
        return RebuildHeader(fs, file);
    }

    entry->m_parsed = true;
    return true;
}

// VERIFY: 47edb62c manual
// OFFSET: 0x004572C0
bool Blizzard::Storage::WritePartBlockInfo(Blizzard::Streaming::StorageEntry* entry, Blizzard::File::StreamRecord* file, int32_t block) {
    if (!s_storageReady) {
        return false;
    }

    if (entry->m_flags & 4) {
        return true;
    }

    bool result = true;

    if (block >= 0 && block < static_cast<int32_t>(entry->m_blocks.size())) {
        Blizzard::Streaming::PartBlockRecord record;
        record.m_storeOffset = entry->m_blocks[block].m_storeOffset;
        record.m_state = entry->m_blocks[block].m_state;
        record.m_partOffset = entry->m_blocks[block].m_partOffset;

        result = WriteAt(file, &record, 20LL * block + 52, sizeof(record));

        if (!result) {
            Blizzard::File::AddToLastErrorStack(0, "Failed to write storage information chunk", 20);
        }
    }

    return result;
}

// VERIFY: 27d59f31 manual
// OFFSET: 0x00457390
bool Blizzard::Storage::WriteBlock(Blizzard::Streaming::WriteRequest* request) {
    Blizzard::Streaming::StorageEntry* entry = request->m_entry;
    uint32_t block = static_cast<uint32_t>(request->m_offset / entry->m_blockSize);
    Blizzard::Streaming::StorageBlock& storageBlock = entry->m_blocks[block];
    int32_t state = storageBlock.m_state;

    if (state == 4 || (state != 3 && state != 2)) {
        return state != 0;
    }

    uint8_t* data = request->m_data;
    bool allocated = false;

    if (block == entry->m_blocks.size() - 1 && request->m_size != entry->m_blockSize) {
        allocated = true;
        data = static_cast<uint8_t*>(Blizzard::Memory::Allocate(entry->m_blockSize));
        Blizzard::String::MemCopy(data, request->m_data, request->m_size);
    }

    int64_t position = entry->m_storeSize;
    bool existing = false;

    if (storageBlock.m_storeOffset) {
        position = storageBlock.m_storeOffset;
        existing = true;
    }

    int32_t amount = entry->m_blockSize;

    if (!Blizzard::File::Write(request->m_file, data, position, &amount)) {
        storageBlock.m_state = 0;
        return false;
    }

    if (allocated) {
        Blizzard::Memory::Free(data);
    }

    if (!existing) {
        entry->m_blocks[block].m_storeOffset = position;
        entry->m_storeSize += entry->m_blockSize;
    }

    storageBlock.m_state = 3;

    bool result = s_usePartFiles ? WritePartBlockInfo(entry, request->m_file, block) : WriteIndexEntry(entry, block, false);

    if (!result) {
        if (!existing) {
            entry->m_blocks[block].m_storeOffset = 0;
            entry->m_storeSize -= entry->m_blockSize;
        }

        storageBlock.m_state = 0;
    }

    return result;
}

// VERIFY: 999e8cb7 manual
// OFFSET: 0x00457550
bool Blizzard::Storage::FlushFile(Blizzard::File::Filesystem* fs, Blizzard::File::StreamRecord* file) {
    EnterCriticalSection(&s_storageLock);

    int32_t count = static_cast<int32_t>(s_writeQueue.size());

    for (int32_t i = 0; i < count; i++) {
        Blizzard::Streaming::WriteRequest& request = s_writeQueue[i];

        if (file == request.m_file) {
            if (request.m_pending == 1) {
                WriteBlock(&request);
                request.m_pending = 0;
            }

            if (request.m_data) {
                Blizzard::Memory::Free(request.m_data);
                request.m_data = nullptr;
            }
        }
    }

    if (!s_usePartFiles) {
        WriteIndex();
    }

    file->m_streaming->m_entry->m_released = true;
    LeaveCriticalSection(&s_storageLock);

    while (file->m_streaming->m_entry->m_refCount > 0) {
        Sleep(1);
    }

    return true;
}

// VERIFY: 4a7a69cc manual
// OFFSET: 0x00459660
uint32_t Blizzard::Storage::StorageThread(void* param) {
    if (s_storageStop) {
        s_storageStopped = true;
        return 1;
    }

    do {
        WaitForSingleObject(s_storageEvent, INFINITE);

        if (s_storageStop) {
            break;
        }

        for (;;) {
            EnterCriticalSection(&s_storageLock);

            if (!s_writeQueue.size()) {
                break;
            }

            Blizzard::Streaming::WriteRequest& request = s_writeQueue.front();

            if (request.m_pending == 1) {
                WriteBlock(&request);

                if (request.m_data) {
                    Blizzard::Memory::Free(request.m_data);
                    request.m_data = nullptr;
                }
            }

            s_writeQueue.pop_front();
            LeaveCriticalSection(&s_storageLock);

            if (s_storageStop) {
                s_storageStopped = true;
                return 1;
            }
        }

        LeaveCriticalSection(&s_storageLock);
    } while (!s_storageStop);

    s_storageStopped = true;
    return 1;
}

// VERIFY: 37d58904 manual
// OFFSET: 0x00459800
bool Blizzard::Storage::Close(Blizzard::File::Filesystem* fs, Blizzard::File::StreamRecord* file, Blizzard::Streaming::StorageEntry* entry) {
    if (entry->m_flags & 4) {
        return true;
    }

    EnterCriticalSection(&s_storageLock);

    if ((entry->m_flags & 1) && IsComplete(entry)) {
        entry->m_closed = true;
        LeaveCriticalSection(&s_storageLock);
        return true;
    }

    bool result = FlushFile(fs, file);

    for (std::vector<Blizzard::Streaming::StorageBlock>::iterator it = entry->m_blocks.begin(); it != entry->m_blocks.end(); ++it) {
        if (it->m_state != 3) {
            it->m_state = 0;
        }
    }

    LeaveCriticalSection(&s_storageLock);
    return result;
}

// VERIFY: fd87d2fa manual
// OFFSET: 0x0045ADC0
bool Blizzard::Storage::Initialize() {
    s_usePartFiles = true;

    if (!s_storageReady) {
        s_storage = new std::map<std::string, Blizzard::Streaming::StorageEntry>();
        InitializeCriticalSection(&s_storageLock);
        s_storageEvent = CreateEventA(nullptr, FALSE, FALSE, nullptr);
        Blizzard::Thread::CreateDetached(StorageThread, nullptr, "Streaming Storage Thread");
        s_storageReady = true;
    }

    return true;
}

// VERIFY: 9d88e040 manual
// OFFSET: 0x0045AE90
bool Blizzard::Storage::Initialize(const char* path, bool required) {
    s_usePartFiles = false;

    if (s_storageReady) {
        Blizzard::File::AddToLastErrorStack(0, "Storage::Initialize - s_storageReady said we've been here", 20);
        return false;
    }

    s_storage = new std::map<std::string, Blizzard::Streaming::StorageEntry>();
    InitializeCriticalSection(&s_storageLock);
    s_storageEvent = CreateEventA(nullptr, FALSE, FALSE, nullptr);
    Blizzard::Thread::CreateDetached(StorageThread, nullptr, "Streaming Storage Thread");
    s_storageReady = true;

    void* data = nullptr;
    uint32_t size = 0;
    char absolute[260];

    if (!path || !Blizzard::File::MakeAbsolutePath(path, absolute, sizeof(absolute), false)) {
        Blizzard::File::AddToLastErrorStack(0, "Storage::Initialize - MakeAbsolutePath failed", 20);
        return false;
    }

    s_storagePath.assign(absolute, strlen(absolute));

    bool found = false;

    for (int32_t i = 0; i < 25; i++) {
        if (found) {
            break;
        }

        char name[260];
        BuildVariantFileName(name, sizeof(name), path, "");

        if (!Blizzard::File::Exists(name)) {
            break;
        }

        if (Blizzard::File::Open(name, 4099, s_storageFile)) {
            if (!System_File::LoadFile(s_storageFile, &data, &size)) {
                break;
            }

            found = true;
        } else {
            s_variantIndex++;
        }
    }

    if (!found) {
        if (required) {
            Blizzard::File::AddToLastErrorStack(0, "Storage::Initialize - Bad existing storage file", 20);
            return false;
        }

        if (s_storageFile) {
            if (data) {
                Blizzard::Memory::Free(data);
            }

            Blizzard::File::Close(s_storageFile);
            s_storageFile = nullptr;
            Blizzard::File::Delete(path);
        }

        s_usePartFiles = true;
        return true;
    }

    bool result = ReadStorageFile(static_cast<uint8_t*>(data), size);
    Blizzard::Memory::Free(data);

    if (result) {
        return true;
    }

    if (required) {
        Blizzard::File::AddToLastErrorStack(0, "Storage::Initialize - Bad existing storage file", 20);
        return false;
    }

    Blizzard::File::Close(s_storageFile);
    s_storageFile = nullptr;
    s_usePartFiles = true;
    Blizzard::File::Delete(path);
    return true;
}

#endif
